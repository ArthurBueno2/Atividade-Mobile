import { Text, View, StyleSheet, Image,ScrollView } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
<ScrollView style={styles.container}>
  
       
       
      <Text style={styles.paragraph}>
        Bolos incriveis
      </Text>
      
      <View style={styles.div}>
     <Text style={styles.paragraph}>
        Floresta negra
      </Text>
      <Image style={styles.img}
      resizeMode="auto"
      source={require('./assets/bolo-floresta-negra.jpeg')}
      />
        <Text style={styles.paragraph}>
        R$ 99,30
      </Text>

      <Text style={styles.paragraph1}>
        Um bolo de Floresta Negra é uma deliciosa sobremesa de origem alemã, conhecida por sua combinação única de sabores e texturas. Ele é feito com camadas de bolo de chocolate rico e fofo, recheadas com uma mistura de cerejas frescas ou em conserva e creme de chantilly, e muitas vezes finalizado com raspas de chocolate ou lascas de chocolate escuro.
      </Text>
     </View >

    
    <View style={styles.div}>
     <Text style={styles.paragraph}>
        Red Velvet
      </Text>
      <Image style={styles.img}
      resizeMode="auto"
      source={require('./assets/bolo-red-velvet.jpeg')}
      />
        <Text style={styles.paragraph}>
        R$ 150
      </Text>
      <Text style={styles.paragraph1}>
Um bolo Red Velvet é uma criação culinária notável, conhecida por sua cor vermelha vibrante e sabor distinto. Originado nos Estados Unidos, esse bolo é adorado por sua textura macia e sabor suavemente achocolatado, muitas vezes contrastado com um rico e cremoso frosting de queijo.
      </Text>
     </View >

         
         
         <View style={styles.div}>
     <Text style={styles.paragraph}>
       Prestígio
      </Text>
      <Image style={styles.img}
      resizeMode="auto"
      source={require('./assets/bolo-prestigio.jpg')}
      />
        <Text style={styles.paragraph}>
        R$ 53,90
      </Text>

      <Text style={styles.paragraph1}>
        Um bolo de prestígio é uma sobremesa indulgente e deliciosa, originária do Brasil, conhecida por sua combinação irresistível de chocolate e coco. Ele é muitas vezes apreciado em festas, comemorações ou simplesmente como um mimo indulgente em qualquer ocasião.
      </Text>
     </View >
         
         
         <View style={styles.div}>
     <Text style={styles.paragraph}>
        Neite Ninho
      </Text>
      <Image style={styles.img}
      resizeMode="auto"
      source={require('./assets/bolo-mousse-leite-ninho.jpg')}
      />
      <Text style={styles.paragraph}>
        R$ 94,90
      </Text>

      <Text style={styles.paragraph1}>
        Um bolo de leite em pó (Leite Ninho) é uma sobremesa que ganhou popularidade, especialmente no Brasil, devido ao sabor suave e agradável do leite em pó. Esse bolo é conhecido por sua textura macia e úmida, juntamente com um sabor delicado e levemente doce.
      </Text>
     </View >
         
         
         <View style={styles.div}>
     <Text style={styles.paragraph}>
        Fuba com Goiabada
      </Text>
      <Image style={styles.img}
      resizeMode="auto"
      source={require('./assets/bolo-fuba-cremoso-goiabada.jpg')}
      />
      <Text style={styles.paragraph}>
        R$ 32,12
      </Text>

      <Text style={styles.paragraph1}>
        Um bolo de fubá com goiabada é uma combinação encantadora de sabores, que traz a rusticidade do fubá e a doçura única da goiabada. Essa receita tradicional brasileira é apreciada por muitos devido à sua simplicidade e ao equilíbrio perfeito entre os ingredientes.
      </Text>

      <Text style= {styles.paragraph}>

      </Text>
     </View >
  
  
  </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 0,
    justifyContent: 'center',
    backgroundColor: '#8b0000',
    padding: 8,
   
  },
  paragraph: {
  
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#FF8C00',
  },
  paragraph1:
  {
      width: 300,
  },
  img:
  {
    width: 200,
    height:150,
    borderRadius: 20
  },
  div:
  {
    marginTop:40,
    flex: 0,
    alignItems: 'center',
    justifyContent:'center',
    borderRadius : 10,
    backgroundColor: '#F0E68C',  
    height:350,
    width: 350,
    marginLeft: 15,
    
  }
});
